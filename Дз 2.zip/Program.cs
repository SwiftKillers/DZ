﻿using System;

namespace School
{
    class Program
    {
        static void Main(string[] args)
        {
            School.jobhunters.Add(new School.JobHunter("Иванов Александр Александрович", School.SchoolWorkers.Jobs.JobHunter));
            Console.WriteLine($"{School.jobhunters[0].FIO}: {School.jobhunters[0].jobes}");
  
            School.jobhunters.Add(new School.JobHunter("Крюкова Ольга Петровна", School.SchoolWorkers.Jobs.JobHunter));
            Console.WriteLine($"{School.jobhunters[1].FIO}: {School.jobhunters[1].jobes}");
            Console.WriteLine(" ");

            Console.WriteLine(School.jobhunters[0].JAction1("Дудник Андрей Романович", School.SchoolWorkers.Jobs.Assistant));
            Console.WriteLine(School.jobhunters[1].JAction1("Багдарасян Рафаэль Нагатович", School.SchoolWorkers.Jobs.Senior_lecturer));

            Console.WriteLine(School.teachers[0].TAction());
            Console.WriteLine(School.teachers[1].TAction());
            Console.WriteLine(" ");

            Console.WriteLine(School.jobhunters[0].JAction2("Воробьев Антон Юрьевич", 3));
            Console.WriteLine(School.students[0].SAction());
            Console.WriteLine(" ");

            Console.WriteLine(School.jobhunters[1].JAction2("Узмаки Наруто Минатович ", 4));
            Console.WriteLine(School.students[1].SAction());
            Console.ReadLine();
        }
    }
}
